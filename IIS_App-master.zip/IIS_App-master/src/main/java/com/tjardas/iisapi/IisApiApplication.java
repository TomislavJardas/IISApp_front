package com.tjardas.iisapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IisApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(IisApiApplication.class, args);
    }

}

package com.tjardas.iisapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IisApiApplicationTests {

    @Test
    void contextLoads() {
    }

}

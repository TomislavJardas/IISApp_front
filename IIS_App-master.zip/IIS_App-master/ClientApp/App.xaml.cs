using System.Windows;

namespace ClientApp
{
    public partial class App : Application
    {
    }
}

package com.tjardas.ngrelax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NgRelaxApplicationTests {

    @Test
    void contextLoads() {
    }

}
